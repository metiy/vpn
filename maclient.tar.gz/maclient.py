#!/usr/bin/python
import os, sys,getopt, struct ,subprocess,binascii,time,string,hashlib,random
from socket import *
from fcntl import ioctl
from select import select


#please modify this feild
serveraddress  = "xxx.xxx.xxx.xxx"


#please modify this feild
key            = 'please change this!!!'


#please confim this feild
port           = 3000

#please confim this feild
gateway        = '192.168.7.1'


def rc4_python(data,key):
    x = 0
    box = range(256)
    for i in range(256):
        x = (x + box[i] + ord(key[i % len(key)])) % 256
        box[i], box[x] = box[x], box[i]
    x = 0
    y = 0
    out = []
    for char in data:
        x = (x + 1) % 256
        y = (y + box[x]) % 256
        box[x], box[y] = box[y], box[x]
        out.append(chr(ord(char) ^ box[(box[x] + box[y]) % 256]))

    return ''.join(out)

def GetTunHandle():
    # Open TUN device file.
    tun = os.open("/dev/tap13", os.O_RDWR)
    return tun


def GetUDPHandle(p):
    s = socket(AF_INET, SOCK_DGRAM)
    return s

def EncodeData(mac  , plain):
    global key
    md4 = hashlib.new('md4')
    md4.update(key)
    data = rc4_python(plain,md4.hexdigest())

    head = ''
    for i in range(20):
        head = head + random.choice(ascii_str)

    ciphertext = head + data

    return ciphertext

def DecodeData(ciphertext):
    global key
    md4 = hashlib.new('md4')
    md4.update(key)
    plain = rc4_python(ciphertext[20:],md4.hexdigest())
    return plain

def GetRoute():
    cmd     = 'netstat -rn'
    ret     = subprocess.Popen(cmd , stdout=subprocess.PIPE ,shell=True)
    output  = ret.stdout.readlines()
    r       = {}
    for l in output:
        k = l.split()
        if len(k) < 5 :
            continue
        if k[0] == 'default':
            r['gateway']   = k[1]
            r['interface'] = k[5]
    return r
try:
    ascii     = []
    tunhandle = GetTunHandle()
    udphandle = GetUDPHandle(port)

    for i in range(0,256):
        ascii.append(chr(i))

    ascii_str = string.join(ascii)

    # route delete -net 0.0.0.0 -ifp en0
    # route add default 192.168.7.1
    # route add -host 203.88.172.99 192.168.20.254
    subprocess.check_call("ifconfig tap13 mtu 1440" , shell=True)
    subprocess.check_call("ipconfig set tap13 dhcp" , shell=True)

    default = GetRoute()
    print default

    cmd     = 'route add -host %s %s' % ( serveraddress , default['gateway'] )
    subprocess.check_call(cmd , shell=True)

    cmd     = 'route delete -net 0.0.0.0 -ifp %s' % ( default['interface'] , )
    subprocess.check_call(cmd , shell=True)

    cmd     = 'route add default -iface tap13'
    subprocess.check_call(cmd , shell=True)

    while True:
        r = select([tunhandle,udphandle],[],[])[0][0]

        if r == tunhandle:
            packet = os.read(tunhandle,2048)
            dst = packet[0:6]
            ciphertext = EncodeData(dst , packet)
            print "%-5d write data to %s" % (len(ciphertext),  binascii.b2a_hex(dst) )
            if len(ciphertext) > 12 :
                udphandle.sendto( ciphertext , (serveraddress , port ) )

        if r == udphandle:
            packet , peer = udphandle.recvfrom(2048)
            if peer[1] == 0:
                continue

            plaintext = DecodeData(packet)
            dst = plaintext[0:6]
            print '%-5d read  udp     %s' %  (len(plaintext) , binascii.b2a_hex(dst) )
            os.write(tunhandle,  plaintext)

except KeyboardInterrupt:
    print "\nStopped by user."

    cmd     = 'route delete -host %s' % ( serveraddress , )
    subprocess.check_call(cmd , shell=True)
    
    cmd     = 'route delete default'
    subprocess.check_call(cmd , shell=True)
    
    cmd     = 'route add default %s' % (default['gateway'], )
    subprocess.check_call(cmd , shell=True)
