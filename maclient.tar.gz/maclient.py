#!/usr/bin/python
import os, sys,getopt, struct ,subprocess,binascii,time,string,hashlib,random
from socket import *
from fcntl import ioctl
from select import select

port           = 3000
gateway        = '192.168.7.1'

#serveraddress  = "218.247.184.229"
#key            = '1.pl*A-3#8765gkufxctyIURTYFK,b289756'
#key            = 'Please change this key!!!!'

serveraddress  = "203.88.172.99"
key            = 'ifuhio8-euh8734763$^^&Y4KV'

def rc4_python(data,key):
    x = 0
    box = range(256)
    for i in range(256):
        x = (x + box[i] + ord(key[i % len(key)])) % 256
        box[i], box[x] = box[x], box[i]
    x = 0
    y = 0
    out = []
    for char in data:
        x = (x + 1) % 256
        y = (y + box[x]) % 256
        box[x], box[y] = box[y], box[x]
        out.append(chr(ord(char) ^ box[(box[x] + box[y]) % 256]))

    return ''.join(out)

def GetTunHandle():
    # Open TUN device file.
    tun = os.open("/dev/tap13", os.O_RDWR)
    return tun


def GetUDPHandle(p):
    s = socket(AF_INET, SOCK_DGRAM)
    return s

def EncodeData(mac  , plain):
    global key
    md4 = hashlib.new('md4')
    md4.update(key)
    data = rc4_python(plain,md4.hexdigest())

    head = ''
    for i in range(20):
        head = head + random.choice(ascii_str)

    ciphertext = head + data

    return ciphertext

def DecodeData(ciphertext):
    global key
    md4 = hashlib.new('md4')
    md4.update(key)
    plain = rc4_python(ciphertext[20:],md4.hexdigest())
    return plain

try:
    ascii     = []
    tunhandle = GetTunHandle()
    udphandle = GetUDPHandle(port)

    for i in range(0,256):
        ascii.append(chr(i))

    ascii_str = string.join(ascii)

    # route delete -net 0.0.0.0 -ifp en0
    # route add default 192.168.7.1
    # route add -host 203.88.172.99 192.168.20.254
    subprocess.check_call("ifconfig tap13 mtu 1440" , shell=True)
    subprocess.check_call("ipconfig set tap13 dhcp" , shell=True)

    ret     = subprocess.Popen('route get default' , stdout=subprocess.PIPE ,shell=True)
    default = ret.stdout.readlines()
    print default

    ret     = subprocess.Popen('route get ' + serveraddress , stdout=subprocess.PIPE ,shell=True)
    server  = ret.stdout.readlines()
    print server

    cmd     = 'route add -host %s %s' % ( serveraddress , server[3].split(':')[1].strip() )
    print cmd
    subprocess.check_call(cmd , shell=True)

    cmd     = 'route delete -net 0.0.0.0 -ifp %s' % ( default[4].split(':')[1].strip() , )
    print cmd
    subprocess.check_call(cmd , shell=True)

    cmd     = 'route add default -iface tap13'
    print cmd
    subprocess.check_call(cmd , shell=True)

    while True:
        r = select([tunhandle,udphandle],[],[])[0][0]

        if r == tunhandle:
            packet = os.read(tunhandle,2048)
            dst = packet[0:6]
            ciphertext = EncodeData(dst , packet)
            print "%-5d write data to %s" % (len(ciphertext),  binascii.b2a_hex(dst) )
            if len(ciphertext) > 12 :
                udphandle.sendto( ciphertext , (serveraddress , port ) )

        if r == udphandle:
            packet , peer = udphandle.recvfrom(2048)
            if peer[1] == 0:
                continue

            plaintext = DecodeData(packet)
            dst = plaintext[0:6]
            print '%-5d read  udp     %s' %  (len(plaintext) , binascii.b2a_hex(dst) )
            os.write(tunhandle,  plaintext)

except KeyboardInterrupt:
    print "\nStopped by user."

    cmd     = 'route delete -host %s' % ( serveraddress , )
    print cmd
    subprocess.check_call(cmd , shell=True)
    
    cmd     = 'route delete default'
    print cmd
    subprocess.check_call(cmd , shell=True)
    
    cmd     = 'route add default %s' % (default[3].split(':')[1].strip() , )
    print cmd
    subprocess.check_call(cmd , shell=True)
