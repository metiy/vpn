#!/usr/bin/python

# tap device ipaddress
# string
# default is 192.168.7.1
# ipaddress = "192.168.7.1"


# udp port
# int
# default is 3000
# port      =  3000


# adapter name
# string ( length < 15 )
# default is tzmvpn
# adapter   = "tzmvpn"


# mtu for apater
# int
# default is 1440
# mtu       = 1440


# boardcast , is set true , forward between clients
# bool
# default is false
# boardcast = False


# default is true
#singleusermode = True


# key for RC4
# string
# if singleusermode  is True , use this key
key       =  "Please change this string!!!!"

