#!/usr/bin/python
import os, sys,getopt, struct ,subprocess,binascii,time,string,hashlib,random
from socket import *
from fcntl import ioctl
from select import select

import M2Crypto

# file config.py
import config


ipaddress      = "192.168.7.1"
port           =  3000
adapter        = "tzmvpn"
mtu            = 1440
boardcast      = False
singleusermode = True
key            = '1.pl*A-3#8765gkufxctyIURTYFK,b289756'

if hasattr(config , "ipaddress"):
    ipaddress = config.ipaddress

if hasattr(config , "port"):
    port = config.port

if hasattr(config , "adapter"):
    adapter = config.adapter

if hasattr(config , "mtu"):
    mtu = config.mtu

if hasattr(config , "boardcast"):
    boardcast = config.boardcast

if hasattr(config , "singleusermode"):
    singleusermode = config.singleusermode

if hasattr(config , "key"):
    key = config.key


def rc4_python(data,key):
    x = 0
    box = range(256)
    for i in range(256):
        x = (x + box[i] + ord(key[i % len(key)])) % 256
        box[i], box[x] = box[x], box[i]
    x = 0
    y = 0
    out = []
    for char in data:
        x = (x + 1) % 256
        y = (y + box[x]) % 256
        box[x], box[y] = box[y], box[x]
        out.append(chr(ord(char) ^ box[(box[x] + box[y]) % 256]))

    return ''.join(out)

rc4   = M2Crypto.RC4.RC4()

def GetTunHandle():
    # Some constants used to ioctl the device file. I got them by a simple C
    # program.
    TUNSETIFF   = 0x400454ca
    TUNSETOWNER = TUNSETIFF + 2
    IFF_TUN     = 0x0001
    IFF_TAP     = 0x0002
    IFF_NO_PI   = 0x1000

    # Open TUN device file.
    tun = os.open("/dev/net/tun", os.O_RDWR)
    # Tall it we want a TUN device named tzmvpn.
    ifr = struct.pack('16sH', adapter , IFF_TAP | IFF_NO_PI)
    ioctl(tun, TUNSETIFF, ifr)

    # Optionally, we want it be accessed by the normal user.
    ioctl(tun, TUNSETOWNER, 1000)

    # Bring it up and assign addresses.
    subprocess.check_call("ifconfig %s %s mtu %d"%(adapter ,ipaddress,mtu ),shell=True)
    return tun

def GetUDPHandle(p):
    s = socket(AF_INET, SOCK_DGRAM)
    s.bind(("", p))
    return s

def EncodeData(mac  , plain):
    global key
    md4 = hashlib.new('md4')
    md4.update(key)
    rc4.set_key(md4.hexdigest())
    data = rc4.update(plain)

    head = ''
    for i in range(20):
        head = head + random.choice(ascii_str)

    ciphertext = head + data

    return ciphertext

def DecodeData(ciphertext):
    global key
    md4 = hashlib.new('md4')
    md4.update(key)
    rc4.set_key(md4.hexdigest())
    plain = rc4.update(ciphertext[20:])
    return plain

try:
    ascii     = []
    clients   = {}
    tunhandle = GetTunHandle()
    udphandle = GetUDPHandle(port)
    LastTime  = time.time()

    for i in range(0,256):
        ascii.append(chr(i))

    ascii_str = string.join(ascii)

    while True:
        r = select([tunhandle,udphandle],[],[])[0][0]
        CurrTime  = time.time()
        if r == tunhandle:
            packet = os.read(tunhandle,2048)
            dst = packet[0:6]
            if boardcast and dst == '\xff\xff\xff\xff\xff\xff':
                print "%-5d Boardcast data to %s" % (len(packet),  binascii.b2a_hex(dst) )
                for mac in clients.keys():
                    peer , l  = clients[mac]
                    ciphertext = EncodeData(mac , packet)
                    if len(ciphertext) > 12 :
                        udphandle.sendto( ciphertext , peer )
            elif clients.has_key(dst):
                peer , l  = clients[dst]
                ciphertext = EncodeData(dst , packet)
                print "%-5d write data to %s" % (len(ciphertext),  binascii.b2a_hex(dst) ) , peer
                if len(ciphertext) > 12 :
                    udphandle.sendto( ciphertext , peer )

        if r == udphandle:
            packet , peer = udphandle.recvfrom(2048)
            if peer[1] == 0:
                continue

            plaintext = DecodeData(packet)
            if len(plaintext) > 12:
                src = plaintext[6:12]
                dst = plaintext[0:6]
                clients[src] = (peer , CurrTime)

                if boardcast and dst == '\xff\xff\xff\xff\xff\xff':
                    print "%-5d Boardcast from %s" % (len(plaintext) , binascii.b2a_hex(src) )
                    for mac in clients.keys():
                        p  , l  = clients[mac]
                        if p != peer:
                            ciphertext = EncodeData(mac , plaintext)
                            if len(ciphertext) > 12 :
                                udphandle.sendto(ciphertext  , p )
                else:
                    print "%-5d get data from %s" % (len(plaintext) , binascii.b2a_hex(src) ) , peer

                os.write(tunhandle,  plaintext)

        # remove lagel mac older then 10min
        if(CurrTime - LastTime > 300):
            for mac in clients.keys():
                peer , l  = clients[mac]
                if( CurrTime - l > 600 ):
                    del clients[mac]

        LastTime  = CurrTime

except KeyboardInterrupt:
    print "Stopped by user."
