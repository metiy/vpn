#
#
#                Copyright (c) MetiyClub.
#
#


Module Name:
	TZM VPN


INSTALL:
	Not Need


REMOVE:
	open device manager
	delete the
		MetiyClub Virtual Ethernet Adapter (NDIS 6.00)


USE:
	run    tzmvpn.exe

